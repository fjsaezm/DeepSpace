/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package deepspace;

/**
 *
 * @author fjaviersaezm
 * Represents the possible outcomes of a shot in the game
 */
public enum ShotResult {
    DONOTRESIST,RESIST
}
